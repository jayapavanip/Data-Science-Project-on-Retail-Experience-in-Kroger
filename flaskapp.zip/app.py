from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import pyodbc
import pandas as pd
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import joblib
import os
import json
from sklearn.preprocessing import LabelEncoder

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = 'cloud_final_project'

UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = {'csv'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

users = {}

# Azure SQL connection function
def get_db_connection():
    conn = pyodbc.connect(
        'Driver={ODBC Driver 17 for SQL Server};'
        'Server=cloudsqlserver44.database.windows.net;'
        'Database=cloudsql44;'
        'UID=sqladmin;'
        'PWD=Group_44;'
    )
    return conn

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('login.html')

# Route for the registration page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        if username in users:
            flash("Username already exists. Please choose another.", "error")
            return redirect(url_for('register'))

        users[username] = {
            'email': email,
            'password': password
        }
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = users.get(username)
        if not user:  # Check if the user is not registered
            flash("User not registered. Please register first.", "error")
            return redirect(url_for('register'))  # Redirect to the register page
        
        if user['password'] == password:
            session['username'] = username
            flash("Login successful!", "success")
            return redirect(url_for('home'))
        else:
            flash("Invalid username or password.", "error")
            return redirect(url_for('login'))
    return render_template('login.html')


# Route for the home page
@app.route('/home')
def home():
    if 'username' not in session:
        flash("Please log in first.", "error")
        return redirect(url_for('login'))   

    conn = get_db_connection()
    query = "SELECT * FROM TransformedData WHERE Hshd_num = 10 ORDER BY Hshd_num, Basket_num, Purchase_Date, Product_num, Department, Commodity"
    sample_data = pd.read_sql(query, conn)
    conn.close()
    return render_template('index.html', data=sample_data.to_html(index=False))

# Route to handle search requests
@app.route('/search', methods=['POST'])
def search():
    if 'username' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    hshd_num = request.form['hshd_num']  # Get Hshd_num from form
    conn = get_db_connection()
    query = f"SELECT * FROM TransformedData WHERE Hshd_num = {hshd_num} ORDER BY Hshd_num, Basket_num, Purchase_Date, Product_num, Department, Commodity"
    data = pd.read_sql(query, conn)
    conn.close()
    return render_template('results.html', data=data.to_html(index=False))

# Route for the upload page
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'username' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    if request.method == 'POST':
        year = request.form['year']
        transactions_file = request.files['transactions_file']
        products_file = request.files['products_file']
        households_file = request.files['households_file']

        if not all([transactions_file, products_file, households_file]):
            flash("All three files (Transactions, Products, Households) are required.")
            return redirect(url_for('upload'))

        for file in [transactions_file, products_file, households_file]:
            if not allowed_file(file.filename):
                flash("Only CSV files are allowed.")
                return redirect(url_for('upload'))

        # Save files
        transactions_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(transactions_file.filename))
        products_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(products_file.filename))
        households_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(households_file.filename))
        transactions_file.save(transactions_path)
        products_file.save(products_path)
        households_file.save(households_path)

        # Load data into SQL tables
        conn = get_db_connection()
        transactions_data = pd.read_csv(transactions_path)
        products_data = pd.read_csv(products_path)
        households_data = pd.read_csv(households_path)
        
        transactions_data.columns = transactions_data.columns.str.strip()
        products_data.columns = products_data.columns.str.strip()
        households_data.columns = households_data.columns.str.strip()

        # Correct column order for Transactions
        transactions_columns = [
            'HSHD_NUM',
            'BASKET_NUM',
            'PURCHASE_',
            'PRODUCT_NUM',
            'SPEND',
            'UNITS',
            'STORE_R',
            'WEEK_NUM',
            'YEAR'
        ]

        # Correct column order for Products
        products_columns = [
            'PRODUCT_NUM',
            'DEPARTMENT',
            'COMMODITY',
            'BRAND_TY',
            'NATURAL_ORGANIC_FLAG'
        ]

        # Correct column order for Households
        households_columns = [
            'HSHD_NUM',
            'L',
            'AGE_RANGE',
            'MARITAL',
            'INCOME_RANGE',
            'HOMEOWNER',
            'HSHD_COMPOSITION',
            'HH_SIZE',
            'CHILDREN'
        ]

        # Reorder Transactions DataFrame
        transactions_data = transactions_data[transactions_columns]

        # Reorder Products DataFrame
        products_data = products_data[products_columns]

        # Reorder Households DataFrame
        households_data = households_data[households_columns]

        # Load Transactions
        for _, row in transactions_data.iterrows():
            conn.execute("INSERT INTO [dbo].[Transactions] VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", tuple(row))

        # Load Products
        for _, row in products_data.iterrows():
            conn.execute("INSERT INTO [dbo].[Products] VALUES (?, ?, ?, ?, ?)", tuple(row))

        # Load Households
        for _, row in households_data.iterrows():
            conn.execute("INSERT INTO [dbo].[Households] VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", tuple(row))

        conn.commit()

        # Incrementally update TransformedData for the selected year
        join_query = f"""
        INSERT INTO [dbo].[TransformedData]
        SELECT
            t.Hshd_num,
            t.Basket_num,
            t.Purchase_Date,
            t.Product_num,
            p.Department,
            p.Commodity,
            t.Spend,
            t.Units,
            t.Store_region,
            t.Week_num,
            t.Year,
            h.Loyalty_flag,
            h.Age_range,
            h.Marital_status,
            h.Income_range,
            h.Homeowner_desc,
            h.Hshd_composition,
            h.Hshd_size,
            h.Children
        FROM [dbo].[Transactions] t
        JOIN [dbo].[Products] p ON t.Product_num = p.Product_num
        JOIN [dbo].[Households] h ON t.Hshd_num = h.Hshd_num
        WHERE t.Year = {year};
        """
        conn.execute(join_query)
        conn.commit()
        conn.close()

        flash(f"Data for {year} uploaded and processed successfully!")
        return redirect(url_for('home'))

    return render_template('upload.html')

# Load models
model_clv = joblib.load("model/gradient_boosting_clv.pkl")
model_basket = joblib.load("model/random_forest_basket.pkl")
model_churn = joblib.load("model/logistic_regression_churn.pkl")

encoder = LabelEncoder()
# Pre-fit the encoder with the specified Store_region values
store_regions = ['CENTRAL', 'EAST', 'SOUTH', 'WEST']  # Updated Store_region values
encoder.fit(store_regions)

@app.route('/clv_predict', methods=['GET', 'POST'])
def clv_predict():
    if request.method == 'POST':
        data = request.get_json()
        df = pd.DataFrame(data, index=[0])
        prediction = model_clv.predict(df)
        return jsonify({"CLV Prediction": prediction.tolist()})
    return render_template('clv_predict.html')  # Render a form if GET request

@app.route('/basket_predict', methods=['GET', 'POST'])
def basket_predict():
    if request.method == 'POST':
        data = request.get_json()
        df = pd.DataFrame(data, index=[0])
        df['Store_region_encoded'] = encoder.transform([df['Store_region'][0]])
        df = df[['Spend', 'Units', 'Hshd_size', 'Children', 'Income_range', 'Store_region_encoded']]
        prediction = model_basket.predict(df)
        return jsonify({"Basket Analysis": prediction.tolist()})
    return render_template('basket_predict.html')  # Render a form if GET request

@app.route('/churn_predict', methods=['GET', 'POST'])
def churn_predict():
    if request.method == 'POST':
        data = request.get_json()
        df = pd.DataFrame(data, index=[0])
        prediction = model_churn.predict(df)
        return jsonify({"Churn Prediction": prediction.tolist()})
    return render_template('churn_predict.html')  # Render a form if GET request
    
# Route for the dashboard page
# Route for the dashboard page
@app.route('/dashboard')
def dashboard():
    # Check if user is logged in
    if 'username' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    # Establish database connection
    conn = get_db_connection()

    # Query 1: Demographics and Engagement
    query_demo = """
        SELECT Store_region, Age_range, AVG(Spend) as avg_spend, AVG(Units) as avg_units
        FROM TransformedData
        GROUP BY Store_region, Age_range
    """
    df_demo = pd.read_sql(query_demo, conn)

    # Query 2: Engagement Over Time
    query_time = """
        SELECT Year, Month(Purchase_Date) as Month, SUM(Spend) as total_spend
        FROM TransformedData
        GROUP BY Year, Month(Purchase_Date)
        ORDER BY Year, Month(Purchase_Date)
    """
    df_time = pd.read_sql(query_time, conn)

    # Query 3: Basket Analysis
    query_basket = """
        SELECT TOP 5 Commodity, COUNT(*) as count
        FROM TransformedData
        GROUP BY Commodity
        ORDER BY COUNT(*) DESC
    """
    df_basket = pd.read_sql(query_basket, conn)

    # Query 4: Seasonal Trends
    query_season = """
        SELECT Month(Purchase_Date) as Month, SUM(Spend) as total_spend
        FROM TransformedData
        GROUP BY Month(Purchase_Date)
        ORDER BY Month(Purchase_Date)
    """
    df_season = pd.read_sql(query_season, conn)

    # Query 5: Brand Preferences
    query_brand = """
        SELECT Loyalty_flag, COUNT(*) as count
        FROM TransformedData
        GROUP BY Loyalty_flag
    """
    df_brand = pd.read_sql(query_brand, conn)

    # Close the database connection
    conn.close()

    # Convert data to JSON for the frontend
    data = {
        "demographics": df_demo.to_dict(orient='records'),
        "engagement_over_time": df_time.to_dict(orient='records'),
        "basket_analysis": df_basket.to_dict(orient='records'),
        "seasonal_trends": df_season.to_dict(orient='records'),
        "brand_preferences": df_brand.to_dict(orient='records'),
    }

    # Render the dashboard template with data
    return render_template('dashboard.html', data=json.dumps(data))


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("You have been logged out.")
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
